USE [MongoTNPT]
GO

/****** Object:  Table [dbo].[Developers]    Script Date: 10/12/2014 2:39:01 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Developers](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[First_Name] [varchar](100) NOT NULL,
	[Last_Name] [varchar](100) NOT NULL,
	[Title] [varchar](100) NOT NULL,
	[Birth] [datetime] NOT NULL,
	[Death] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


