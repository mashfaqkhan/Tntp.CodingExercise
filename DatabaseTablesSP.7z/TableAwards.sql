USE [MongoTNPT]
GO

/****** Object:  Table [dbo].[Awards]    Script Date: 10/12/2014 2:35:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Awards](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[First_Name] [varchar](100) NOT NULL,
	[Last_Name] [varchar](100) NOT NULL,
	[Birth] [datetime] NOT NULL,
	[Award] [varchar](250) NULL,
	[Year] [decimal](18, 0) NULL,
	[By] [varchar](250) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


