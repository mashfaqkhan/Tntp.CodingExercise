USE [MongoTNPT]
GO

/****** Object:  StoredProcedure [dbo].[sp_Addcontribs]    Script Date: 10/12/2014 2:40:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Addcontribs] 
	-- Add the parameters for the stored procedure here
	@firstname varchar(100),
    @lastname varchar(100),
	@birth datetime,
	@contribe varchar(250)
	AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	   insert into contribs(first_name, last_name,birth,contribs) values (@firstname,@lastname,@birth,@contribe)

END

GO


