USE [MongoTNPT]
GO

/****** Object:  StoredProcedure [dbo].[sp_Addawards]    Script Date: 10/12/2014 2:39:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Addawards] 
	-- Add the parameters for the
	@firstname varchar(100),
    @lastname varchar(100),
	@birth datetime,
	@award varchar(250),
	@year decimal(18,0),
	@by varchar(250)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	insert into awards(first_name, last_name,birth,award,year,[by]) values (@firstname,@lastname,@birth,@award,@year,@by)
END

GO


