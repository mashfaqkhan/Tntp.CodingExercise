USE [MongoTNPT]
GO

/****** Object:  StoredProcedure [dbo].[sp_Adddeveloper]    Script Date: 10/12/2014 2:41:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Adddeveloper]
	-- Add the parameters for the stored procedure here

	@firstname varchar(100),
    @lastname varchar(100),
	@birth datetime,
	@death datetime=null,
	@title varchar(100)
	AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	insert into developers(first_name, last_name,title,birth,death) values (@firstname,@lastname,@title,@birth,@death)
END

GO


